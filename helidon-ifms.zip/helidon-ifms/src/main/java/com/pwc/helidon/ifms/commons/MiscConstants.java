package com.pwc.helidon.ifms.commons;

public class MiscConstants {

	public static String key = "ifmsoct2022";
}
