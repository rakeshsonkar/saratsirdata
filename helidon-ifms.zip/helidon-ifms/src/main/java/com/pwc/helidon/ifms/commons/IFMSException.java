package com.pwc.helidon.ifms.commons;

public class IFMSException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IFMSException(String message) {
		super(message);
	}
}
