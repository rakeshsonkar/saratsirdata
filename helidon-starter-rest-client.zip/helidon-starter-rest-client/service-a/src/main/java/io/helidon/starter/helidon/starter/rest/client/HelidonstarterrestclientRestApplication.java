package io.helidon.starter.helidon.starter.rest.client;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 */
@ApplicationPath("/data")
public class HelidonstarterrestclientRestApplication extends Application {
}
