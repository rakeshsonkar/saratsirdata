/**
 * 
 */
package in.ifms.employee.exception;

/**
 * @author hp
 *
 *
 *This is the IFMS system base class for all Runtime system exceptions
 */
public class IfmsBaseException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
